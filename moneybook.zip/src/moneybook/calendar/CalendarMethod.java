package moneybook.calendar;

import java.util.ArrayList;
import java.util.Calendar;

public class CalendarMethod {
	CalendarFrame frame;
	
	public ArrayList<Integer> getThisDay(ArrayList<Integer> calArr,int lastDay) {
		for(int i = 0; i<lastDay;i++) {
			calArr.add(i+1);
		}
		return calArr;
	}
	
	public ArrayList<Integer> getLastDay(ArrayList<Integer> calArr,int lastDay,int yoil){
		for(int i =0; i<yoil-1;i++) {
			calArr.add(0,lastDay);
			lastDay--;
		}
		return calArr;
	}
	
/*	public void addMonth(int i) {
		frame.cal.add(Calendar.MONTH, i);
	} */
}
