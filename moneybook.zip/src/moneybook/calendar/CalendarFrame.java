package moneybook.calendar;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class CalendarFrame extends JFrame {
	Calendar cal = Calendar.getInstance();
	int year = cal.get(Calendar.YEAR);
	int month = cal.get(Calendar.MONTH);
	int day = cal.get(Calendar.DATE);
	int lastDay = cal.getActualMaximum(Calendar.DATE);
	int yoil = cal.get(Calendar.DAY_OF_WEEK); // ������ ���� ����
	String header[] = {"��","��","ȭ","��","��","��","��"};

	JPanel pan = new JPanel(); // ���
	JPanel pan1 = new JPanel(); // ����
	ArrayList<Integer> calArr = new ArrayList<Integer>();
	CalendarMethod c = new CalendarMethod();
	
	ImageIcon icon = new ImageIcon(".\\src\\moneybook\\calendar\\IMG\\�»�ǥ.png");
	ImageIcon icon1 = new ImageIcon(".\\src\\moneybook\\calendar\\IMG\\���ǥ.png");
	
	JButton btn1 = new JButton(icon);
	JButton btn2 = new JButton(icon1);
	
	JLabel label = new JLabel(cal.get(Calendar.YEAR)+"��"+(cal.get(Calendar.MONTH)+1)+"��",SwingConstants.CENTER);
	CalendarFrame(){
		super.setName("����� �޷�");
		super.setLayout(new BorderLayout());
		
		// ���� �޷� �߰�
		c.getThisDay(calArr, lastDay);
		// ������ �߰�
		cal.set(Calendar.DATE,1);
		yoil = cal.get(Calendar.DAY_OF_WEEK);
		cal.add(Calendar.MONTH, -1);
		lastDay = cal.getActualMaximum(Calendar.DATE);
		c.getLastDay(calArr, lastDay, yoil);
		//����� �޷� ���
		for(int i =0; i<calArr.size();i++) {
			System.out.print(calArr.get(i)+".");
			if(i%7 ==6) {
				System.out.println();
			}
		}
		
		//�����ӿ� �� �߰�
		super.add(pan,"Center");
		super.add(pan1,"North");
		pan.setLayout(new GridLayout(0,7));
	//	pan1.setLayout(new BorderLayout());
		//��1�� ���� �� ��ư ���
		label.setPreferredSize(new Dimension(500,50));
		pan1.add(btn1);
		pan1.add(label);
		pan1.add(btn2);
		btn1.setPreferredSize(new Dimension(50, 50));
		label.setFont(new Font("", Font.BOLD, 20));
		
		btn2.setPreferredSize(new Dimension(50, 50));
		
		//�ǿ� ��� �߰�
		for(int i = 0; i<header.length;i++) {
			JButton btn = new JButton(header[i]);
			pan.add(btn);
			if(i%7 == 0) {
				btn.setForeground(Color.RED);
			}else if(i%7==6){
				btn.setForeground(Color.RED);
			}
		}
		//�ǿ� �޷� �߰�
		for(int i = 0; i<calArr.size(); i++) {
			JButton btn = new JButton(calArr.get(i)+"");
			pan.add(btn);
			if(i%7 == 0) {
				btn.setForeground(Color.RED);
			}else if(i%7==6){
				btn.setForeground(Color.RED);
			}
		}
		super.setSize(640, 700);
		super.setDefaultCloseOperation(EXIT_ON_CLOSE);
		super.setLocationRelativeTo(null);
		super.setResizable(false);
		super.setVisible(true);
		
		CalendarEventListener listener = new CalendarEventListener(this);
		//��ư �׼� �ֱ�
		btn1.addActionListener(listener);
		btn2.addActionListener(listener);
		
		
		}
		

	public static void main(String[] args) {
		new CalendarFrame();
	}

	
}
