package moneybook.calendar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

public class CalendarEventListener implements ActionListener{

	CalendarFrame frame;
	
	public CalendarEventListener(CalendarFrame frame) {
		this.frame = frame;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		if(e.getSource() == frame.btn1) {
			System.out.println(frame.cal.get(Calendar.MONTH));
			new CalendarFrame();
		}else if(e.getSource() == frame.btn2) {
			System.out.println("btn2");
		}
	}

}
